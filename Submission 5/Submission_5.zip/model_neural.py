import os
import json
import warnings
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.colors as mcolors
import seaborn as sns
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from collections import Counter
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report
)
from sklearn.utils.class_weight import compute_class_weight

warnings.filterwarnings("ignore")

# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════════════════

INPUT_DIR    = "/kaggle/input/datasets/suprimdevkota/testing-1/"
OUTPUT_DIR   = "/kaggle/working/testing-4/"
RANDOM_STATE  = 42
N_CONV_LAYERS = 1  

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)

# ── Hyperparameter Search ─────────────────────────────────────────────────────
N_TRIALS    = 64   # random configs evaluated per outer fold
TUNE_FOLDS  = 3    # inner-CV folds per trial
TUNE_EPOCHS = 20   # epochs per inner trial

# ── Outer (unbiased) Evaluation ───────────────────────────────────────────────
FINAL_FOLDS  = 5
FINAL_EPOCHS = 50

# ── Sequence Length ───────────────────────────────────────────────────────────
# None → computed per fold as the 95th-percentile of *training* sequence lengths.
# Override with an integer to cap memory usage, e.g. MAX_SEQ_LEN = 50_000.
MAX_SEQ_LEN = 50_000

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

SEARCH_SPACE = {
    "embed_dim":     [16, 32],
    "n_filters":     [64, 128],
    "filter_size":   [16, 32],
    "hidden_dim":    [64, 128],
    "learning_rate": [1e-2, 1e-3],
    "batch_size":    [16, 32],
}


os.makedirs(OUTPUT_DIR, exist_ok=True)
tune_dir = os.path.join(OUTPUT_DIR, "tuning")
cm_dir   = os.path.join(OUTPUT_DIR, "confusion_matrices")
os.makedirs(tune_dir, exist_ok=True)
os.makedirs(cm_dir,   exist_ok=True)

# ══════════════════════════════════════════════════════════════════════════════
#  1. Load Shared Artifacts
# ══════════════════════════════════════════════════════════════════════════════

print("=" * 65)
print("  CNN MALWARE CLASSIFIER  —  Nested CV + Hyperparameter Tuning")
print("=" * 65)
print("\n[ Step 1 ] Loading shared artifacts...")

y           = np.load(os.path.join(INPUT_DIR, "y.npy"))
class_names = np.load(os.path.join(INPUT_DIR, "class_names.npy"), allow_pickle=True)


with open(os.path.join(INPUT_DIR, "samples.json")) as f:
    raw_samples = json.load(f)

tokenized = [s.split() for s in raw_samples]

# ── Label remapping ───────────────────────────────────────────────────────────
unique_classes = np.unique(y)
n_classes      = len(unique_classes)

# Derive all_labels from the remapped range — not from an external file —
# so metrics are always consistent with the actual label set.
all_labels = np.arange(n_classes)

if not np.array_equal(unique_classes, all_labels):
    label_map = {old: new for new, old in enumerate(unique_classes)}
    y = np.array([label_map[yi] for yi in y], dtype=np.int64)
    print(f"  ⚠  Labels remapped to [0, {n_classes})")
else:
    print(f"  Labels already in [0, {n_classes}) — no remapping needed.")

print(f"  Device      : {DEVICE}")
print(f"  Classes     : {n_classes}")
print(f"  Samples     : {len(y)}")
print(f"  Outer folds : {FINAL_FOLDS}  × {FINAL_EPOCHS} epochs  (unbiased eval)")
print(f"  Inner CV    : {N_TRIALS} trials × {TUNE_FOLDS}-fold × {TUNE_EPOCHS} epochs  (tuning)")

PAD_IDX = 0
UNK_IDX = 1

# ══════════════════════════════════════════════════════════════════════════════
#  2. Vocabulary + Encoding  (fold-local — called inside the outer CV loop)
# ══════════════════════════════════════════════════════════════════════════════

def build_vocab(sequences):
    """
    Build vocabulary from a list of tokenized sequences.
    Must be called only on *training* sequences to prevent data leakage.
    Returns the vocab list and a token→index mapping.
    """
    counter    = Counter(tok for seq in sequences for tok in seq)
    vocab      = ["<PAD>", "<UNK>"] + sorted(counter.keys())
    opcode2idx = {op: i for i, op in enumerate(vocab)}
    return vocab, opcode2idx


def encode_and_pad(sequences, max_len, opcode2idx):
    """
    Encode sequences using a given vocabulary mapping and pad/truncate to max_len.
    Tokens absent from opcode2idx (e.g. test-only opcodes) map to UNK_IDX.
    """
    encoded = np.full((len(sequences), max_len), PAD_IDX, dtype=np.int64)
    for i, seq in enumerate(sequences):
        idxs = [opcode2idx.get(tok, UNK_IDX) for tok in seq[:max_len]]
        encoded[i, : len(idxs)] = idxs
    return encoded

# ══════════════════════════════════════════════════════════════════════════════
#  3. CNN Model
# ══════════════════════════════════════════════════════════════════════════════

class MalwareCNN(nn.Module):
    """
    1-D CNN over opcode-index sequences.
    Embedding → L × (Conv1d + ReLU) → GlobalMaxPool → ReLU(FC) → FC(logits)
    """
    def __init__(self, vocab_size, embed_dim, n_filters, filter_size,
                 n_conv_layers, hidden_dim, n_classes, pad_idx=0):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=pad_idx)

        conv_blocks, in_ch = [], embed_dim
        for _ in range(n_conv_layers):
            conv_blocks += [
                nn.Conv1d(in_ch, n_filters, kernel_size=filter_size,
                          padding=filter_size // 2),
                nn.ReLU(),
            ]
            in_ch = n_filters
        self.conv_layers = nn.Sequential(*conv_blocks)

        self.fc_hidden = nn.Linear(n_filters, hidden_dim)
        self.relu      = nn.ReLU()
        self.fc_out    = nn.Linear(hidden_dim, n_classes)

    def forward(self, x):
        emb = self.embedding(x).permute(0, 2, 1)       # (B, E, L)
        f   = self.conv_layers(emb).max(dim=2).values  # (B, F)
        return self.fc_out(self.relu(self.fc_hidden(f)))


def make_model(cfg, vocab_size):
    """Instantiate a MalwareCNN from a hyperparameter config dict."""
    return MalwareCNN(
        vocab_size    = vocab_size,
        embed_dim     = cfg["embed_dim"],
        n_filters     = cfg["n_filters"],
        filter_size   = cfg["filter_size"],
        n_conv_layers = N_CONV_LAYERS,
        hidden_dim    = cfg["hidden_dim"],
        n_classes     = n_classes,
        pad_idx       = PAD_IDX,
    ).to(DEVICE)

# ══════════════════════════════════════════════════════════════════════════════
#  4. Helpers
# ══════════════════════════════════════════════════════════════════════════════

def build_class_weights(y_fold):
    """
    Return a weight tensor of length n_classes for CrossEntropyLoss.
    Classes absent from this fold get weight 0 (their gradient is silenced).
    A warning is emitted so the caller is aware rather than silently surprised.
    """
    present = np.unique(y_fold)
    missing = set(range(n_classes)) - set(present.tolist())
    if missing:
        warnings.warn(
            f"Classes {missing} are absent from this fold. "
            "Their CrossEntropyLoss weights will be zero.",
            RuntimeWarning,
        )
    cw_vals = compute_class_weight("balanced", classes=present, y=y_fold)
    weights = np.zeros(n_classes, dtype=np.float32)
    for cls, w in zip(present, cw_vals):
        weights[cls] = w
    return torch.tensor(weights).to(DEVICE)


def train_one_epoch(model, loader, criterion, optimizer):
    model.train()
    total = 0.0
    for Xb, yb in loader:
        Xb, yb = Xb.to(DEVICE), yb.to(DEVICE)
        optimizer.zero_grad()
        loss = criterion(model(Xb), yb)
        loss.backward()
        optimizer.step()
        total += loss.item() * len(yb)
    return total / len(loader.dataset)


@torch.no_grad()
def predict(model, loader):
    model.eval()
    preds = []
    for Xb, _ in loader:
        preds.append(model(Xb.to(DEVICE)).argmax(1).cpu().numpy())
    return np.concatenate(preds)


def compute_metrics(y_true, y_pred):
    kw = dict(average="weighted", labels=all_labels, zero_division=0)
    return {
        "Accuracy":  round(accuracy_score(y_true, y_pred), 4),
        "Precision": round(precision_score(y_true, y_pred, **kw), 4),
        "Recall":    round(recall_score(y_true, y_pred, **kw), 4),
        "F-measure": round(f1_score(y_true, y_pred, **kw), 4),
    }


def train_and_eval(cfg, vocab_size, X_tr, y_tr, X_te, y_te, n_epochs, verbose=False):
    y_tr_np = y_tr.numpy() if isinstance(y_tr, torch.Tensor) else y_tr

    criterion    = nn.CrossEntropyLoss(weight=build_class_weights(y_tr_np))
    train_loader = DataLoader(TensorDataset(X_tr, y_tr),
                              batch_size=cfg["batch_size"], shuffle=True)
    test_loader  = DataLoader(TensorDataset(X_te, y_te),
                              batch_size=cfg["batch_size"], shuffle=False)

    model     = make_model(cfg, vocab_size)
    optimizer = optim.Adam(model.parameters(), lr=cfg["learning_rate"])

    losses = []
    for epoch in range(1, n_epochs + 1):
        loss = train_one_epoch(model, train_loader, criterion, optimizer)
        losses.append(loss)
        if verbose:
            print(f"      Epoch {epoch:>2}/{n_epochs}  loss: {loss:.4f}")

    preds = predict(model, test_loader)

    del model, optimizer, criterion, train_loader, test_loader
    torch.cuda.empty_cache()

    return preds, losses


def run_inner_cv(cfg, vocab_size, X, y_tensor, n_folds, n_epochs):
    """
    Inner stratified k-fold CV used solely for hyperparameter selection.
    Vocabulary (and therefore vocab_size) must already be derived from the
    outer training split — this function never sees outer test data.
    Returns the mean weighted F1 across inner folds.
    """
    skf    = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    y_np   = y_tensor.numpy()
    all_true, all_pred = [], []

    for tr_idx, te_idx in skf.split(X.numpy(), y_np):
        preds, _ = train_and_eval(
            cfg, vocab_size,
            X[tr_idx], y_tensor[tr_idx],
            X[te_idx], y_tensor[te_idx],
            n_epochs,
        )
        all_true.extend(y_np[te_idx])
        all_pred.extend(preds)

    return f1_score(np.array(all_true), np.array(all_pred),
                    average="weighted", labels=all_labels, zero_division=0)


def sample_configs(space, n, seed=RANDOM_STATE):
    """Sample n unique configurations via random search."""
    rng = random.Random(seed)
    configs, seen = [], set()
    attempts = 0
    while len(configs) < n and attempts < n * 200:
        attempts += 1
        cfg = {k: rng.choice(v) for k, v in space.items()}
        key = tuple(sorted(cfg.items()))
        if key not in seen:
            seen.add(key)
            configs.append(cfg)
    if len(configs) < n:
        print(f"  ⚠  Only {len(configs)} unique configs found (requested {n}).")
    return configs


def plot_confusion_matrix(y_true, y_pred, title, save_path):
    cm      = confusion_matrix(y_true, y_pred, labels=all_labels)
    rs      = cm.sum(axis=1, keepdims=True)
    rs[rs == 0] = 1
    cm_norm = cm.astype(float) / rs

    n     = len(class_names)
    fig_w = max(14, n * 0.55)
    fig_h = max(6,  n * 0.35)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    fig.suptitle(title, fontsize=13, fontweight="bold", y=1.02)
    fs = max(5, min(9, 180 // n))
    sns.heatmap(cm_norm, annot=True, fmt=".2f", cmap="Blues",
                xticklabels=class_names, yticklabels=class_names,
                ax=ax, annot_kws={"size": fs}, linewidths=0.3, linecolor="#e0e0e0")
    ax.set_title("Normalized (Row %)", fontweight="bold")
    ax.set_xlabel("Predicted", fontsize=10)
    ax.set_ylabel("Actual",    fontsize=10)
    ax.tick_params(axis="x", rotation=90, labelsize=fs)
    ax.tick_params(axis="y", rotation=0,  labelsize=fs)
    plt.tight_layout()
    plt.savefig(save_path, dpi=130, bbox_inches="tight")
    plt.close()

# ══════════════════════════════════════════════════════════════════════════════
#  5. Nested Cross-Validation
#
#  Outer loop  — provides an unbiased performance estimate.
#    Each outer fold produces a held-out test set the model has never seen,
#    including during vocabulary construction and hyperparameter selection.
#
#  Inner loop  — selects hyperparameters using only outer-fold training data.
#    Vocabulary is built from the outer training split, so test-fold opcodes
#    never influence what tokens the model knows about.
# ══════════════════════════════════════════════════════════════════════════════

print(f"\n{'=' * 65}")
print("  NESTED CV  —  Outer: unbiased eval  |  Inner: HP tuning")
print(f"{'=' * 65}")

outer_skf         = StratifiedKFold(n_splits=FINAL_FOLDS, shuffle=True,
                                    random_state=RANDOM_STATE)
outer_true        = []
outer_pred        = []
final_loss_curves = []
all_tune_records  = []   # tuning rows from every outer fold
best_cfgs         = []   # best config selected per outer fold

for outer_fold, (outer_tr_idx, outer_te_idx) in enumerate(
        outer_skf.split(np.zeros(len(y)), y), 1):

    print(f"\n  ── Outer Fold {outer_fold}/{FINAL_FOLDS} "
          f"({'─' * 44})")

    # ── Build vocabulary strictly from outer training sequences ──────────────
    # Test-fold opcodes are unknown here; they will map to <UNK> at encode time.
    train_seqs = [tokenized[i] for i in outer_tr_idx]
    test_seqs  = [tokenized[i] for i in outer_te_idx]

    vocab, opcode2idx = build_vocab(train_seqs)
    fold_vocab_size   = len(vocab)

    # Sequence length cap derived from training data only
    train_lengths = [len(tokenized[i]) for i in outer_tr_idx]
    fold_max_seq  = (MAX_SEQ_LEN if MAX_SEQ_LEN is not None
                     else int(np.percentile(train_lengths, 95)))

    # Encode — unseen test opcodes become <UNK> automatically
    X_outer_tr = torch.from_numpy(encode_and_pad(train_seqs, fold_max_seq, opcode2idx))
    X_outer_te = torch.from_numpy(encode_and_pad(test_seqs,  fold_max_seq, opcode2idx))
    y_outer_tr = torch.from_numpy(y[outer_tr_idx].astype(np.int64))
    y_outer_te = torch.from_numpy(y[outer_te_idx].astype(np.int64))

    print(f"    Vocab size  : {fold_vocab_size}")
    print(f"    Max seq len : {fold_max_seq}")
    print(f"    Train / Test: {len(outer_tr_idx)} / {len(outer_te_idx)}")

    # ── Inner CV: hyperparameter search on outer training data only ──────────
    # Use a different seed per fold so the search explores more of the space
    # across folds without introducing any dependence on test labels.
    print(f"\n    Inner CV: {N_TRIALS} trials × {TUNE_FOLDS}-fold × {TUNE_EPOCHS} epochs")

    configs      = sample_configs(SEARCH_SPACE, N_TRIALS,
                                  seed=RANDOM_STATE + outer_fold)
    tune_records = []

    for trial_i, cfg in enumerate(configs, 1):
        inner_f1 = run_inner_cv(cfg, fold_vocab_size,
                                X_outer_tr, y_outer_tr,
                                TUNE_FOLDS, TUNE_EPOCHS)
        print(f"      Trial {trial_i:>2}/{N_TRIALS}  F1={inner_f1:.4f}  "
              f"embed={cfg['embed_dim']} filters={cfg['n_filters']} "
              f"ks={cfg['filter_size']} hidden={cfg['hidden_dim']} "
              f"lr={cfg['learning_rate']} bs={cfg['batch_size']}")
        tune_records.append({**cfg,
                              "inner_F-measure": round(inner_f1, 4),
                              "outer_fold": outer_fold})

    all_tune_records.extend(tune_records)

    df_fold_tune = (pd.DataFrame(tune_records)
                    .sort_values("inner_F-measure", ascending=False)
                    .reset_index(drop=True))

    # Restore Python native types (pandas may cast to numpy scalars)
    raw_best = df_fold_tune.iloc[0].drop(["inner_F-measure", "outer_fold"]).to_dict()
    fold_best_cfg = {
        "embed_dim":     int(raw_best["embed_dim"]),
        "n_filters":     int(raw_best["n_filters"]),
        "filter_size":   int(raw_best["filter_size"]),
        "hidden_dim":    int(raw_best["hidden_dim"]),
        "learning_rate": float(raw_best["learning_rate"]),
        "batch_size":    int(raw_best["batch_size"]),
    }
    best_cfgs.append(fold_best_cfg)

    print(f"\n    Best inner config "
          f"(inner F1={df_fold_tune['inner_F-measure'].iloc[0]:.4f}): "
          f"{fold_best_cfg}")

    # ── Train on full outer training split, evaluate on held-out outer test ──
    print(f"\n    Training best config on full outer train ({FINAL_EPOCHS} epochs)...")
    preds, fold_losses = train_and_eval(
        fold_best_cfg, fold_vocab_size,
        X_outer_tr, y_outer_tr,
        X_outer_te, y_outer_te,
        FINAL_EPOCHS, verbose=True,
    )

    fold_acc = accuracy_score(y_outer_te.numpy(), preds)
    print(f"    → Outer fold {outer_fold} accuracy: {fold_acc:.4f}")

    outer_true.extend(y_outer_te.numpy())
    outer_pred.extend(preds)
    final_loss_curves.append(fold_losses)

outer_true = np.array(outer_true)
outer_pred = np.array(outer_pred)

# ══════════════════════════════════════════════════════════════════════════════
#  6. Aggregate Results
# ══════════════════════════════════════════════════════════════════════════════

metrics = compute_metrics(outer_true, outer_pred)

print(f"\n{'=' * 65}")
print("  AGGREGATED RESULTS  (Nested CV — unbiased estimate)")
print(f"{'=' * 65}")
print(f"\n  {'Metric':<12} {'Score':>8}")
print(f"  {'-' * 22}")
for name, val in metrics.items():
    print(f"  {name:<12} {val:>8.4f}")

print(f"\n  Per-class Report ({FINAL_FOLDS}-fold outer CV aggregated):")
print(classification_report(
    outer_true, outer_pred,
    labels=all_labels, target_names=class_names, zero_division=0,
))

# ── Save CSVs ─────────────────────────────────────────────────────────────────
final_row = {
    "Model":         "MalwareCNN-NestedCV",
    "n_conv_layers": N_CONV_LAYERS,   # explicit constant — not a tuned parameter
    "outer_folds":   FINAL_FOLDS,
    "outer_epochs":  FINAL_EPOCHS,
    "inner_folds":   TUNE_FOLDS,
    "inner_epochs":  TUNE_EPOCHS,
    "n_trials":      N_TRIALS,
    **metrics,
    "note": "Nested CV — best config may differ per outer fold; see best_configs_per_fold.csv",
}
pd.DataFrame([final_row]).to_csv(
    os.path.join(OUTPUT_DIR, "final_results.csv"), index=False
)

df_tune_all = (pd.DataFrame(all_tune_records)
               .sort_values(["outer_fold", "inner_F-measure"],
                             ascending=[True, False])
               .reset_index(drop=True))
tune_csv = os.path.join(tune_dir, "tuning_results.csv")
df_tune_all.to_csv(tune_csv, index_label="Rank")

pd.DataFrame([{"outer_fold": i + 1, **cfg}
              for i, cfg in enumerate(best_cfgs)]).to_csv(
    os.path.join(OUTPUT_DIR, "best_configs_per_fold.csv"), index=False
)

print(f"  Saved: final_results.csv")
print(f"  Saved: best_configs_per_fold.csv")
print(f"  Saved: {tune_csv}")

# ══════════════════════════════════════════════════════════════════════════════
#  7. Tuning Visualizations
#  Use outer fold 1 as the representative sample for per-HP charts so the
#  plots show a single clean trial set rather than pooling across folds.
# ══════════════════════════════════════════════════════════════════════════════

print(f"\n[ Step 4 ] Generating tuning visualizations...")

hp_names  = list(SEARCH_SPACE.keys())
hp_labels = {
    "embed_dim":     "Embedding Dim",
    "n_filters":     "Num Filters",
    "filter_size":   "Filter Size",
    "hidden_dim":    "Hidden Dim",
    "learning_rate": "Learning Rate",
    "batch_size":    "Batch Size",
}

df_fold1 = df_tune_all[df_tune_all["outer_fold"] == 1].copy()

# ── 7a. Effect of each HP on inner F-measure ─────────────────────────────────
n_hp  = len(hp_names)
ncols = 3
nrows = (n_hp + ncols - 1) // ncols
fig, axes = plt.subplots(nrows, ncols, figsize=(6 * ncols, 4.5 * nrows))
fig.suptitle(
    f"Effect of Each Hyperparameter on Inner F-measure\n"
    f"({TUNE_FOLDS}-fold inner CV, outer fold 1, {N_TRIALS} trials)",
    fontsize=14, fontweight="bold", y=1.01,
)

for ax, hp in zip(axes.flatten(), hp_names):
    groups = {}
    for _, row in df_fold1.iterrows():
        groups.setdefault(row[hp], []).append(row["inner_F-measure"])

    sorted_keys = sorted(groups.keys(), key=float)
    data        = [groups[k] for k in sorted_keys]
    labels      = [str(k) for k in sorted_keys]

    bp = ax.boxplot(data, patch_artist=True, widths=0.5,
                    medianprops=dict(color="black", linewidth=2))
    palette = plt.cm.Blues(np.linspace(0.35, 0.8, len(sorted_keys)))
    for patch, color in zip(bp["boxes"], palette):
        patch.set_facecolor(color)

    for i, vals in enumerate(data, 1):
        jitter = np.random.uniform(-0.08, 0.08, size=len(vals))
        ax.scatter(np.full(len(vals), i) + jitter, vals,
                   color="#e05c5c", zorder=5, s=30, alpha=0.85)

    ax.set_xticks(range(1, len(labels) + 1))
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_title(hp_labels[hp], fontweight="bold")
    ax.set_ylabel("Inner F-measure")
    ax.set_ylim(max(0, df_fold1["inner_F-measure"].min() - 0.05),
                min(1.05, df_fold1["inner_F-measure"].max() + 0.05))
    ax.grid(axis="y", linestyle="--", alpha=0.5)

for ax in axes.flatten()[n_hp:]:
    ax.set_visible(False)

plt.tight_layout()
plt.savefig(os.path.join(tune_dir, "hp_effects.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  Saved: hp_effects.png")

# ── 7b. Top-N configurations bar chart ───────────────────────────────────────
top_n  = min(10, len(df_fold1))
top_df = df_fold1.sort_values("inner_F-measure", ascending=False).head(top_n).copy()
top_df["label"] = [
    f"T{rank}: lr={row.learning_rate:.0e} f={int(row.n_filters)} "
    f"ks={int(row.filter_size)} h={int(row.hidden_dim)}"
    for rank, (_, row) in enumerate(top_df.iterrows(), 1)
]

cmap   = plt.cm.RdYlGn
colors = [cmap(v) for v in np.linspace(0.3, 0.9, top_n)]

fig, ax = plt.subplots(figsize=(14, max(5, top_n * 0.55)))
ax.barh(top_df["label"][::-1], top_df["inner_F-measure"][::-1],
        color=colors[::-1], edgecolor="black", linewidth=0.5)
ax.set_xlabel("Inner F-measure (weighted avg)", fontsize=11)
ax.set_title(
    f"Top {top_n} Configurations — Outer Fold 1 Inner CV  "
    f"({TUNE_FOLDS}-fold, {TUNE_EPOCHS} epochs)",
    fontsize=13, fontweight="bold",
)
ax.set_xlim(0, min(1.1, top_df["inner_F-measure"].max() + 0.1))
ax.xaxis.set_major_formatter(mticker.FormatStrFormatter("%.2f"))
ax.grid(axis="x", linestyle="--", alpha=0.5)
for bar, val in zip(ax.patches, top_df["inner_F-measure"][::-1]):
    ax.text(bar.get_width() + 0.005, bar.get_y() + bar.get_height() / 2,
            f"{val:.4f}", va="center", fontsize=9)
plt.tight_layout()
plt.savefig(os.path.join(tune_dir, "top_configs.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  Saved: top_configs.png")

# ── 7c. Pairwise interaction heatmaps ────────────────────────────────────────
# Note: with only N_TRIALS random draws many cells will be empty (NaN).
# The subtitle makes this explicit so blank cells are not misread as zero.
pairs = [("learning_rate", "n_filters"), ("filter_size", "hidden_dim")]
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle(
    "Pairwise HP Interaction — best inner F-measure per cell\n"
    "(blank = no trial landed on this combination with only "
    f"{N_TRIALS} random draws)",
    fontsize=13, fontweight="bold",
)

for ax, (hp_x, hp_y) in zip(axes, pairs):
    pivot = (df_fold1.groupby([hp_x, hp_y])["inner_F-measure"]
             .max()
             .unstack(hp_y)
             .sort_index(axis=0).sort_index(axis=1))
    sns.heatmap(pivot, annot=True, fmt=".3f", cmap="YlGnBu",
                linewidths=0.5, ax=ax, vmin=0, vmax=1,
                annot_kws={"size": 9})
    ax.set_title(f"{hp_labels[hp_x]}  ×  {hp_labels[hp_y]}", fontweight="bold")
    ax.set_xlabel(hp_labels[hp_y])
    ax.set_ylabel(hp_labels[hp_x])

plt.tight_layout()
plt.savefig(os.path.join(tune_dir, "pairwise_heatmaps.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  Saved: pairwise_heatmaps.png")

# ── 7d. Parallel coordinates ──────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(14, 6))
fig.suptitle(
    f"Parallel Coordinates — Outer Fold 1 Trials  (colour = inner F-measure)",
    fontsize=13, fontweight="bold",
)

plot_cols   = hp_names
x_positions = np.arange(len(plot_cols))

norm_df = df_fold1[plot_cols].copy()
for col in plot_cols:
    col_min, col_max = norm_df[col].min(), norm_df[col].max()
    norm_df[col] = ((norm_df[col] - col_min) / (col_max - col_min)
                    if col_max > col_min else 0.5)

f_vals  = df_fold1["inner_F-measure"].values
f_norm  = (f_vals - f_vals.min()) / max(f_vals.max() - f_vals.min(), 1e-9)
cmap_pc = plt.cm.RdYlGn

for row_norm, row_f in zip(norm_df.itertuples(index=False), f_norm):
    ax.plot(x_positions, list(row_norm), color=cmap_pc(row_f),
            linewidth=1.2 + row_f * 1.5, alpha=0.4 + row_f * 0.5)

for xi, col in enumerate(plot_cols):
    ax.axvline(xi, color="black", linewidth=0.8)
    unique_vals = sorted(df_fold1[col].unique(), key=float)
    step = max(1, len(unique_vals) // 4)
    for tick_i, val in enumerate(unique_vals[::step]):
        val_min, val_max = df_fold1[col].min(), df_fold1[col].max()
        y_pos = ((val - val_min) / max(val_max - val_min, 1e-9)
                 if val_max > val_min else 0.5)
        # Alternate vertical alignment to prevent label pile-up
        va = "bottom" if tick_i % 2 == 0 else "top"
        ax.text(xi, y_pos, f"{val:g}", ha="center", va=va,
                fontsize=7.5, color="#333333",
                bbox=dict(fc="white", ec="none", pad=0.5))

ax.set_xticks(x_positions)
ax.set_xticklabels([hp_labels[c] for c in plot_cols], fontsize=9)
ax.set_yticks([])
ax.set_ylim(-0.05, 1.15)

sm = plt.cm.ScalarMappable(cmap=cmap_pc,
                            norm=mcolors.Normalize(vmin=f_vals.min(),
                                                   vmax=f_vals.max()))
sm.set_array([])
cb = plt.colorbar(sm, ax=ax, fraction=0.02, pad=0.02)
cb.set_label("Inner F-measure", fontsize=9)

plt.tight_layout()
plt.savefig(os.path.join(tune_dir, "parallel_coords.png"), dpi=150, bbox_inches="tight")
plt.close()
print(f"  Saved: parallel_coords.png")

# ── 7e. F-measure distribution ────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 4))
ax.hist(df_fold1["inner_F-measure"], bins=10, color="#4C72B0",
        edgecolor="black", alpha=0.85)
ax.axvline(df_fold1["inner_F-measure"].max(), color="green", linewidth=2,
           linestyle="--",
           label=f"Best: {df_fold1['inner_F-measure'].max():.4f}")
ax.axvline(df_fold1["inner_F-measure"].mean(), color="orange", linewidth=2,
           linestyle="--",
           label=f"Mean: {df_fold1['inner_F-measure'].mean():.4f}")
ax.set_xlabel("Inner F-measure", fontsize=11)
ax.set_ylabel("Number of Trials")
ax.set_title(
    f"Inner F-measure Distribution — Outer Fold 1 ({N_TRIALS} Trials)",
    fontsize=13, fontweight="bold",
)
ax.legend()
ax.grid(axis="y", linestyle="--", alpha=0.5)
plt.tight_layout()
plt.savefig(os.path.join(tune_dir, "fmeasure_distribution.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print(f"  Saved: fmeasure_distribution.png")

# ══════════════════════════════════════════════════════════════════════════════
#  8. Final Model Visualizations
# ══════════════════════════════════════════════════════════════════════════════

print(f"\n[ Step 5 ] Generating final model charts...")

# ── 8a. Training loss curves ──────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 5))
for fold_i, losses in enumerate(final_loss_curves, 1):
    ax.plot(range(1, FINAL_EPOCHS + 1), losses, marker="o", markersize=2,
            label=f"Outer Fold {fold_i}")
ax.set_title(
    f"Training Loss — Best Config per Outer Fold  ({FINAL_EPOCHS} epochs)",
    fontsize=13, fontweight="bold",
)
ax.set_xlabel("Epoch")
ax.set_ylabel("Cross-Entropy Loss (class-balanced)")
ax.legend(title="Fold", fontsize=9)
ax.grid(linestyle="--", alpha=0.5)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "final_loss_curves.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print(f"  Saved: final_loss_curves.png")

# ── 8b. Aggregated metrics bar ────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 5))
colors_bar = ["#4C72B0", "#DD8452", "#55A868", "#C44E52"]
bars = ax.bar(list(metrics.keys()), list(metrics.values()),
              color=colors_bar, edgecolor="black", width=0.5)
ax.set_title(
    f"MalwareCNN — Nested {FINAL_FOLDS}-fold CV Metrics  (unbiased estimate)",
    fontsize=13, fontweight="bold",
)
ax.set_ylabel("Score")
ax.set_ylim(0, 1.08)
ax.grid(axis="y", linestyle="--", alpha=0.5)
for bar in bars:
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
            f"{bar.get_height():.4f}", ha="center", va="bottom", fontsize=10)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "final_metrics_bar.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print(f"  Saved: final_metrics_bar.png")

# ── 8c. Per-class F1 ──────────────────────────────────────────────────────────
pcf1 = f1_score(outer_true, outer_pred,
                labels=all_labels, average=None, zero_division=0)
fig, ax = plt.subplots(figsize=(max(10, len(class_names) * 0.6), 5))
ax.bar(class_names, pcf1, color=plt.cm.RdYlGn(pcf1), edgecolor="black")
ax.set_title(
    f"Per-class F1 — Nested {FINAL_FOLDS}-fold CV  (unbiased)",
    fontsize=13, fontweight="bold",
)
ax.set_ylabel("F1 Score")
ax.set_ylim(0, 1.08)
ax.tick_params(axis="x", rotation=90)
ax.grid(axis="y", linestyle="--", alpha=0.5)
for i, v in enumerate(pcf1):
    ax.text(i, v + 0.01, f"{v:.2f}", ha="center", va="bottom", fontsize=8)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "final_per_class_f1.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print(f"  Saved: final_per_class_f1.png")

# ── 8d. Confusion matrix ──────────────────────────────────────────────────────
plot_confusion_matrix(
    outer_true, outer_pred,
    title     = f"MalwareCNN — Nested {FINAL_FOLDS}-fold CV  (unbiased)",
    save_path = os.path.join(cm_dir, "final_confusion_matrix.png"),
)
print(f"  Saved: final_confusion_matrix.png")

# ══════════════════════════════════════════════════════════════════════════════
#  Done
# ══════════════════════════════════════════════════════════════════════════════

print(f"\n{'=' * 65}")
print("  DONE")
print(f"{'=' * 65}")
print(f"""
  Tuning outputs  (results/tuning/):
    tuning_results.csv          — all trials across all outer folds
    hp_effects.png              — HP value vs inner F-measure (outer fold 1)
    top_configs.png             — top-10 configs, outer fold 1
    pairwise_heatmaps.png       — lr×filters and filter_size×hidden_dim grids
    parallel_coords.png         — all fold-1 trials as parallel-coord lines
    fmeasure_distribution.png   — histogram of inner F-measure (fold 1)

  Final model outputs  (results/):
    final_results.csv           — nested-CV metrics (unbiased)
    best_configs_per_fold.csv   — best HP config selected in each outer fold
    final_loss_curves.png       — training loss per outer fold
    final_metrics_bar.png       — accuracy / precision / recall / F1
    final_per_class_f1.png      — per-class F1 bar chart
    confusion_matrices/
      final_confusion_matrix.png
""")