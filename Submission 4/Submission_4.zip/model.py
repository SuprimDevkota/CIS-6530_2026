import os
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
from scipy import sparse
from sklearn.svm import LinearSVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report
)
from sklearn.utils.class_weight import compute_sample_weight
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.preprocessing import Normalizer

warnings.filterwarnings("ignore", category=UserWarning)

# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════════════════

INPUT_DIR    = "preprocessed/"
OUTPUT_DIR   = "results/"
RANDOM_STATE = 42

# Number of CV folds. With MIN_SAMPLES=2 and MERGE_THRESHOLD=5, the smallest
# remaining non-Other class has 5 samples, so 5-fold is safe.
N_FOLDS = 5

# Set to a list of variant names to run only those, e.g.:
#   RUN_VARIANTS = ["bigram__tfidf__k500", "unigram__tfidf__kall"]
# Set to None to run ALL variants from the manifest
# This can also be used to separately run unigram and bigram experiments
RUN_VARIANTS = None

# Save confusion matrices for every model+variant (can be many files).
# False = only save CMs for the best variant per model.
SAVE_ALL_CMS = False

# ══════════════════════════════════════════════════════════════════════════════

os.makedirs(OUTPUT_DIR, exist_ok=True)
cm_dir = os.path.join(OUTPUT_DIR, "confusion_matrices")
os.makedirs(cm_dir, exist_ok=True)

# ── 1. Load Shared Artifacts ──────────────────────────────────────────────────

print("=" * 65)
print("  MODEL EVALUATION PIPELINE  (Cross-Validation)")
print("=" * 65)

print("\n[ Step 1 ] Loading shared artifacts...")

y           = np.load(os.path.join(INPUT_DIR, "y.npy"))
class_names = np.load(os.path.join(INPUT_DIR, "class_names.npy"), allow_pickle=True)
all_labels  = np.load(os.path.join(INPUT_DIR, "all_labels.npy"))

with open(os.path.join(INPUT_DIR, "config.json")) as f:
    config = json.load(f)

with open(os.path.join(INPUT_DIR, "manifest.json")) as f:
    manifest = json.load(f)

# Load raw text samples for per-fold vectorization (avoids data leakage)
with open(os.path.join(INPUT_DIR, "samples.json")) as f:
    samples = json.load(f)
samples = np.array(samples, dtype=object)  # numpy indexing in CV loop

print(f"  Classes    : {len(class_names)}")
print(f"  Samples    : {len(y)}")
print(f"  CV folds   : {N_FOLDS}")
print(f"  Variants   : {len(manifest)}")
print(f"\n  Preprocessing config:")
for k, v in config.items():
    if k != "class_counts":
        print(f"    {k:<18}: {v}")

if RUN_VARIANTS is not None:
    manifest = [m for m in manifest if m["variant"] in RUN_VARIANTS]
    print(f"\n  Running {len(manifest)} selected variant(s).")
else:
    print(f"\n  Running all {len(manifest)} variants.")

# ── 2. Define Models (class weights applied where supported) ──────────────────
#
#  class_weight='balanced' tells SVM and Decision Tree to upweight rare classes
#  proportionally to their inverse frequency — no code changes needed per fold.
#
#  KNN has no native class_weight parameter and fit() does not accept
#  sample_weight either. Instead we apply balanced sample_weight at the
#  scoring stage (compute_metrics + classification_report) per fold.
#
# ─────────────────────────────────────────────────────────────────────────────

def make_models():
    return {
        "SVM": LinearSVC(
            class_weight='balanced',
            random_state=RANDOM_STATE,
            max_iter=5000
        ),
        "KNN_k3": KNeighborsClassifier(n_neighbors=3),
        "KNN_k4": KNeighborsClassifier(n_neighbors=4),
        "KNN_k5": KNeighborsClassifier(n_neighbors=5),
        "Decision Tree": DecisionTreeClassifier(
            class_weight='balanced',
            random_state=RANDOM_STATE
        ),
    }

# ── 3. Helpers ────────────────────────────────────────────────────────────────

def compute_metrics(y_true, y_pred, sample_weight=None):
    """Weighted-average metrics over all folds' concatenated predictions.
    sample_weight is passed for KNN to apply balanced class correction at
    scoring time (KNN does not support class_weight or sample_weight at fit).
    """
    return {
        "Accuracy":  round(accuracy_score(y_true, y_pred,
                                          sample_weight=sample_weight), 4),
        "Precision": round(precision_score(y_true, y_pred, average='weighted',
                                           labels=all_labels, zero_division=0,
                                           sample_weight=sample_weight), 4),
        "Recall":    round(recall_score(y_true, y_pred, average='weighted',
                                        labels=all_labels, zero_division=0,
                                        sample_weight=sample_weight), 4),
        "F-measure": round(f1_score(y_true, y_pred, average='weighted',
                                    labels=all_labels, zero_division=0,
                                    sample_weight=sample_weight), 4),
    }

def plot_confusion_matrix(y_true, y_pred, class_names, all_labels, title, save_path):
    cm = confusion_matrix(y_true, y_pred, labels=all_labels)

    # Safe row normalization — avoid divide-by-zero for empty rows
    row_sums = cm.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    cm_norm = cm.astype(float) / row_sums

    n     = len(class_names)
    fig_w = max(14, n * 0.55)
    fig_h = max(6,  n * 0.35)

    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    fig.suptitle(title, fontsize=13, fontweight='bold', y=1.02)

    font_size = max(5, min(9, 180 // n))

    sns.heatmap(
        cm_norm,
        annot=True,
        fmt='.2f',
        cmap='Blues',
        xticklabels=class_names,
        yticklabels=class_names,
        ax=ax,
        annot_kws={"size": font_size},
        linewidths=0.3,
        linecolor='#e0e0e0'
    )

    ax.set_title('Normalized (Row %)', fontweight='bold')
    ax.set_xlabel("Predicted", fontsize=10)
    ax.set_ylabel("Actual", fontsize=10)
    ax.tick_params(axis='x', rotation=90, labelsize=font_size)
    ax.tick_params(axis='y', rotation=0, labelsize=font_size)

    plt.tight_layout()
    plt.savefig(save_path, dpi=130, bbox_inches='tight')
    plt.close()

# ── 4. Cross-Validation Grid ──────────────────────────────────────────────────

skf             = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_STATE)
all_results     = []
predictions_store = {}   # (model_name, variant_name) -> {y_true, y_pred, sw}

# models_template is used only to count total_runs for progress logging.
# make_models() is called again per variant inside the loop to guarantee
# a completely fresh estimator state before each variant's CV run —
# even though sklearn estimators overwrite state on every fit(), this
# makes the intent explicit and guards against any stateful model added later.
models_template = make_models()
total_runs      = len(manifest) * len(models_template)
run_n           = 0

print(f"\n[ Step 2 ] Cross-validating {total_runs} combinations "
      f"({len(manifest)} variants × {len(models_template)} models × {N_FOLDS} folds)...")

for variant_info in manifest:
    variant_name = variant_info["variant"]
    ngram_range  = tuple(variant_info["ngram_range"])
    vec_type     = variant_info["vectorizer"]
    k            = variant_info["k_int"]   # int or None

    # Fresh model instances per variant to avoid any state bleed
    models = make_models()

    for model_name, model in models.items():
        run_n += 1
        print(f"\n  [{run_n}/{total_runs}] {model_name} | {variant_name}")
        print(f"  {'─' * 58}")

        all_y_true, all_y_pred, all_sw = [], [], []
        last_n_features = None

        for fold, (train_idx, test_idx) in enumerate(skf.split(samples, y), start=1):

            # ── Vectorize: fit ONLY on train fold ───────────────────────────
            if vec_type == "tfidf":
                vec = TfidfVectorizer(ngram_range=ngram_range, sublinear_tf=True)
            elif vec_type == "binary":
                vec = CountVectorizer(ngram_range=ngram_range, binary=True)
            else:
                vec = CountVectorizer(ngram_range=ngram_range, binary=False)

            X_tr = vec.fit_transform(samples[train_idx])   # fit on train only
            X_te = vec.transform(samples[test_idx])        # apply to test

            # ── Feature selection: fit ONLY on train fold ───────────────────
            if k is not None and k < X_tr.shape[1]:
                selector = SelectKBest(chi2, k=k)
                X_tr = selector.fit_transform(X_tr, y[train_idx])
                X_te = selector.transform(X_te)

            # ── Normalizer: no learnable state, but kept inside fold ────────
            # for pipeline consistency and correct sparse/dense handling
            normalizer = Normalizer(norm='l2')
            X_tr = normalizer.fit_transform(X_tr)
            X_te = normalizer.transform(X_te)

            last_n_features = X_tr.shape[1]

            # ── KNN needs dense input ───────────────────────────────────────
            if model_name.startswith("KNN"):
                X_tr = X_tr.toarray() if sparse.issparse(X_tr) else X_tr
                X_te = X_te.toarray() if sparse.issparse(X_te) else X_te

            # SVM/DT use class_weight='balanced' internally at fit time.
            # KNN has no such parameter; balanced weights applied at scoring.
            model.fit(X_tr, y[train_idx])
            y_pred_fold = model.predict(X_te)

            all_y_true.extend(y[test_idx])
            all_y_pred.extend(y_pred_fold)

            if model_name.startswith("KNN"):
                all_sw.extend(compute_sample_weight('balanced', y=y[test_idx]))

            fold_acc = accuracy_score(y[test_idx], y_pred_fold)
            print(f"    Fold {fold}/{N_FOLDS}  accuracy: {fold_acc:.4f}")

        all_y_true = np.array(all_y_true)
        all_y_pred = np.array(all_y_pred)
        sw_final   = np.array(all_sw) if model_name.startswith("KNN") else None

        metrics = compute_metrics(all_y_true, all_y_pred, sample_weight=sw_final)

        # Store numpy arrays separately — not inside the DataFrame
        predictions_store[(model_name, variant_name)] = {
            "y_true": all_y_true,
            "y_pred": all_y_pred,
            "sw":     sw_final,
        }

        # Print aggregated metrics
        print(f"\n  Aggregated over {N_FOLDS} folds:")
        print(f"  {'Metric':<12} {'Score':>8}")
        print(f"  {'-' * 22}")
        for k_name, v in metrics.items():
            print(f"  {k_name:<12} {v:>8.4f}")

        # Per-class report (aggregated predictions)
        print(f"\n  Per-class Report ({N_FOLDS}-fold aggregated):")
        sw_report = sw_final if model_name.startswith("KNN") else None
        print(classification_report(
            all_y_true, all_y_pred,
            labels=all_labels,
            target_names=class_names,
            sample_weight=sw_report,
            zero_division=0
        ))

        # Optional: save CM for every combo
        if SAVE_ALL_CMS:
            cm_title = f"{model_name}  |  {variant_name}  ({N_FOLDS}-fold CV)"
            cm_fname = f"cm__{model_name.replace(' ', '_')}__{variant_name}.png"
            plot_confusion_matrix(
                all_y_true, all_y_pred, class_names, all_labels,
                title=cm_title,
                save_path=os.path.join(cm_dir, cm_fname)
            )
            print(f"  CM saved: {cm_fname}")

        all_results.append({
            "Model":      model_name,
            "Variant":    variant_name,
            "N-gram":     variant_info["ngram"],
            "Vectorizer": vec_type,
            "K-features": variant_info["k_features"],
            # N-features varies slightly per fold (vocab size); last fold used
            "N-features": int(last_n_features),
            **metrics,
        })

# ── 5. Summary Tables ─────────────────────────────────────────────────────────

print(f"\n{'=' * 65}")
print("  FULL RESULTS — Ranked by F-measure")
print(f"{'=' * 65}")

df = (
    pd.DataFrame(all_results)
    .sort_values("F-measure", ascending=False)
    .reset_index(drop=True)
)
df.index += 1

display_cols = ["Model", "Variant", "N-gram", "Vectorizer",
                "K-features", "N-features", "Accuracy", "Precision", "Recall", "F-measure"]

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
print(df[display_cols].to_string(float_format="{:.4f}".format))

csv_path = os.path.join(OUTPUT_DIR, "full_results.csv")
df[display_cols].to_csv(csv_path, index_label="Rank")
print(f"\n  Saved: {csv_path}")

# Best per model
print(f"\n{'=' * 65}")
print("  BEST VARIANT PER MODEL")
print(f"{'=' * 65}")

df_best = (
    df.drop_duplicates(subset="Model")   # df already sorted by F-measure desc
    .reset_index(drop=True)
)
print(df_best[["Model", "Variant", "Accuracy", "Precision",
               "Recall", "F-measure"]].to_string(
    index=False, float_format="{:.4f}".format
))

best_csv = os.path.join(OUTPUT_DIR, "best_per_model.csv")
df_best[display_cols].to_csv(best_csv, index=False)
print(f"\n  Saved: {best_csv}")

# ── 6. Confusion Matrices for Best Variants ───────────────────────────────────

print(f"\n[ Step 3 ] Plotting confusion matrices for best variants...")

for _, row in df_best.iterrows():
    model_name   = row["Model"]
    variant_name = row["Variant"]

    # Retrieve stored aggregated predictions — no refit needed
    preds  = predictions_store[(model_name, variant_name)]
    y_true = preds["y_true"]
    y_pred = preds["y_pred"]

    cm_title  = f"BEST — {model_name}  |  {variant_name}  ({N_FOLDS}-fold CV)"
    cm_fname  = f"best__{model_name.replace(' ', '_')}__{variant_name}.png"
    save_path = os.path.join(cm_dir, cm_fname)

    plot_confusion_matrix(
        y_true, y_pred, class_names, all_labels,
        title=cm_title,
        save_path=save_path
    )
    print(f"  Saved: {cm_fname}")

# ── 7. Visual Comparisons ─────────────────────────────────────────────────────

print(f"\n[ Step 4 ] Generating comparison charts...")

metric_cols   = ["Accuracy", "Precision", "Recall", "F-measure"]
model_palette = {
    "SVM":           "#4C72B0",
    "KNN_k3":        "#DD8452",
    "KNN_k4":        "#DB3A78",
    "KNN_k5":        "#E8A87C",
    "Decision Tree": "#55A868",
}

# ── 7a. Top-20 F-measure horizontal bar chart ─────────────────────────────────

top_n      = min(20, len(df))
top20      = df.head(top_n).copy()
bar_colors = [model_palette[m] for m in top20["Model"]]

fig, ax = plt.subplots(figsize=(16, max(6, top_n * 0.45)))
bars = ax.barh(
    top20["Variant"] + "  [" + top20["Model"] + "]",
    top20["F-measure"],
    color=bar_colors, edgecolor='black', linewidth=0.5
)
ax.set_xlabel("F-measure (weighted avg, CV)", fontsize=11)
ax.set_title(f"Top {top_n} Combinations by F-measure  ({N_FOLDS}-fold CV)",
             fontsize=13, fontweight='bold')
ax.set_xlim(0, 1.08)
ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%.2f'))
ax.invert_yaxis()
ax.grid(axis='x', linestyle='--', alpha=0.5)
for bar, val in zip(bars, top20["F-measure"]):
    ax.text(bar.get_width() + 0.005, bar.get_y() + bar.get_height() / 2,
            f"{val:.4f}", va='center', fontsize=8)
handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in model_palette.values()]
ax.legend(handles, model_palette.keys(), title="Model", loc='lower right')
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "top20_fmeasure.png"), dpi=150, bbox_inches='tight')
plt.close()
print(f"  Saved: top20_fmeasure.png")

# ── 7b. 4-metric bar grid — best variant per model ────────────────────────────

fig, axes = plt.subplots(2, 2, figsize=(13, 9))
fig.suptitle(f"Best Variant per Model — All Metrics  ({N_FOLDS}-fold CV)",
             fontsize=13, fontweight='bold')

for ax, metric in zip(axes.flatten(), metric_cols):
    colors = [model_palette[m] for m in df_best["Model"]]
    bars   = ax.bar(df_best["Model"], df_best[metric],
                    color=colors, edgecolor='black', width=0.5)
    ax.set_title(metric, fontweight='bold')
    ax.set_ylabel("Score")
    ax.set_ylim(0, 1.08)
    ax.tick_params(axis='x', rotation=90)
    ax.grid(axis='y', linestyle='--', alpha=0.5)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                f"{bar.get_height():.4f}", ha='center', va='bottom', fontsize=9)

plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "best_per_model_metrics.png"), dpi=150, bbox_inches='tight')
plt.close()
print(f"  Saved: best_per_model_metrics.png")

# ── 7c. Heatmap — F-measure by n-gram × vectorizer (per model) ───────────────

for model_name in model_palette:
    subset = df[df["Model"] == model_name]
    pivot  = (
        subset
        .groupby(["N-gram", "Vectorizer"])["F-measure"]
        .max()
        .unstack("Vectorizer")
    )
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.heatmap(pivot, annot=True, fmt=".4f", cmap="YlGnBu",
                linewidths=0.5, ax=ax, vmin=0, vmax=1,
                annot_kws={"size": 10})
    ax.set_title(f"{model_name} — Best F-measure: N-gram × Vectorizer  ({N_FOLDS}-fold CV)",
                 fontweight='bold')
    ax.set_xlabel("Vectorizer")
    ax.set_ylabel("N-gram")
    plt.tight_layout()
    fname = f"heatmap_{model_name.replace(' ', '_')}.png"
    plt.savefig(os.path.join(OUTPUT_DIR, fname), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {fname}")

# ── 7d. F-measure vs K-features line chart (per model) ───────────────────────

k_order = sorted(
    df["K-features"].unique(),
    key=lambda x: int(x) if x != "all" else 999999
)

fig, axes = plt.subplots(1, len(model_palette), figsize=(6 * len(model_palette), 5), sharey=True)
fig.suptitle(f"F-measure vs. Feature Count  ({N_FOLDS}-fold CV)",
             fontsize=13, fontweight='bold')

for ax, model_name in zip(axes, model_palette):
    subset = df[df["Model"] == model_name]
    for vec_type, grp in subset.groupby("Vectorizer"):
        grp_k = (
            grp.groupby("K-features")["F-measure"]
            .max()
            .reindex(k_order)
        )
        ax.plot(k_order, grp_k.values, marker='o', label=vec_type)
    ax.set_title(model_name, fontweight='bold')
    ax.set_xlabel("K-features")
    ax.set_ylabel("F-measure")
    ax.set_ylim(0, 1.08)
    ax.grid(linestyle='--', alpha=0.5)
    ax.legend(title="Vectorizer", fontsize=8)

plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "fmeasure_vs_kfeatures.png"), dpi=150, bbox_inches='tight')
plt.close()
print(f"  Saved: fmeasure_vs_kfeatures.png")

# ── Done ──────────────────────────────────────────────────────────────────────

print(f"\n{'=' * 65}")
print("  DONE. All outputs saved to results/")
print(f"{'=' * 65}")
print(f"""
  Files:
    full_results.csv              — all combinations ranked by F-measure
    best_per_model.csv            — best variant per model
    top20_fmeasure.png            — top 20 combos bar chart
    best_per_model_metrics.png    — 4-metric grid for best variants
    heatmap_<Model>.png           — F-measure grid: n-gram × vectorizer
    fmeasure_vs_kfeatures.png     — F-measure vs feature count per model
    confusion_matrices/           — CMs for best variant of each model
""")