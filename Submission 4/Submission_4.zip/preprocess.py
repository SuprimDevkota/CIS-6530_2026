import os
import json
import pickle
import numpy as np
from collections import Counter
from sklearn.preprocessing import LabelEncoder

# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════════════════

DATASET_DIR     = "dataset/"
OUTPUT_DIR      = "preprocessed/"
RANDOM_STATE    = 42
MIN_SAMPLES     = 2       # hard-drop classes with fewer than this many files
MERGE_THRESHOLD = 5       # classes below this get merged into "G0000_Other"

# Grid axes
NGRAM_MODES = {
    "unigram":  (1, 1),
    "bigram":   (2, 2),
}

VECTORIZERS = ["count", "tfidf", "binary"]

# Top-K features via SelectKBest (chi2). None = keep all features
K_FEATURES  = [200, 500, 1000, None]

# ══════════════════════════════════════════════════════════════════════════════

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── 1. Load Raw Opcode Files ──────────────────────────────────────────────────

def load_opcodes(filepath):
    with open(filepath, 'r', errors='ignore') as f:
        return [line.strip().upper() for line in f if line.strip()]

def load_dataset(dataset_dir):
    samples, labels = [], []
    for apt_folder in sorted(os.listdir(dataset_dir)):
        folder_path = os.path.join(dataset_dir, apt_folder)
        if not os.path.isdir(folder_path):
            continue
        for fname in sorted(os.listdir(folder_path)):
            fpath = os.path.join(folder_path, fname)
            opcodes = load_opcodes(fpath)
            if opcodes:
                samples.append(" ".join(opcodes))
                labels.append(apt_folder)
    return samples, labels

print("=" * 65)
print("  PREPROCESSING PIPELINE")
print("=" * 65)

print("\n[ Step 1 ] Loading dataset...")
samples, labels = load_dataset(DATASET_DIR)
print(f"  Loaded {len(samples)} samples across {len(set(labels))} APT groups")

# ── 2. Hard-drop classes below MIN_SAMPLES ───────────────────────────────────

print(f"\n[ Step 2 ] Dropping classes with fewer than {MIN_SAMPLES} samples...")
label_counts = Counter(labels)
dropped = [apt for apt, count in label_counts.items() if count < MIN_SAMPLES]

if dropped:
    print(f"  Dropped {len(dropped)} class(es): {dropped}")
    kept = [(s, l) for s, l in zip(samples, labels) if label_counts[l] >= MIN_SAMPLES]
    samples, labels = zip(*kept)
    samples, labels = list(samples), list(labels)
    label_counts = Counter(labels)
else:
    print(f"  No classes dropped.")

# ── 3. Merge classes below MERGE_THRESHOLD into G0000_Other ──────────────────

print(f"\n[ Step 3 ] Merging classes with fewer than {MERGE_THRESHOLD} samples "
      f"into 'Other'...")

to_merge = [apt for apt, count in label_counts.items() if count < MERGE_THRESHOLD]

if to_merge:
    print(f"  Merging {len(to_merge)} class(es): {to_merge}")
    labels = [
        "Other" if label_counts[l] < MERGE_THRESHOLD else l
        for l in labels
    ]
else:
    print(f"  No classes merged.")

label_counts = Counter(labels)
print(f"\n  Final class distribution ({len(label_counts)} classes):")
for apt, count in sorted(label_counts.items()):
    tag = "  ← merged" if apt == "Other" else ""
    print(f"    {apt:<35} {count:>3} samples{tag}")

# ── 4. Encode Labels ──────────────────────────────────────────────────────────

print("\n[ Step 4 ] Encoding labels...")
le = LabelEncoder()
y = le.fit_transform(labels)
class_names = le.classes_
all_labels  = np.arange(len(class_names))
print(f"  {len(class_names)} classes encoded -> indices 0-{len(class_names) - 1}")

# ── 5. Grid — Build Variant Manifest ─────────────────────────────────────────
#
#  No feature matrices are computed or saved here. Each variant's parameters
#  (n-gram range, vectorizer type, k) are recorded in the manifest so that
#  model.py can reconstruct the full pipeline (vectorize > select > normalize)
#  inside each CV fold, preventing any leakage of test data into feature
#  extraction or feature selection.
#
# ─────────────────────────────────────────────────────────────────────────────

print("\n[ Step 5 ] Building preprocessing grid...")
total    = len(NGRAM_MODES) * len(VECTORIZERS) * len(K_FEATURES)
variant  = 0
manifest = []

samples_list = list(samples)

# Replace the grid loop (Step 5) with this:
for ngram_name, ngram_range in NGRAM_MODES.items():
    for vec_type in VECTORIZERS:
        for k in K_FEATURES:
            variant += 1
            k_label      = str(k) if k is not None else "all"
            variant_name = f"{ngram_name}__{vec_type}__k{k_label}"

            print(f"\n  [{variant}/{total}] {variant_name}")
            manifest.append({
                "variant":    variant_name,
                "ngram":      ngram_name,
                "ngram_range": list(ngram_range),
                "vectorizer": vec_type,
                "k_features": k_label,
                "k_int":      k,          # None or int, used by model.py
            })
# ── 6. Save Shared Artifacts ──────────────────────────────────────────────────

print("\n[ Step 6 ] Saving shared artifacts...")

np.save(os.path.join(OUTPUT_DIR, "y.npy"),           y)
np.save(os.path.join(OUTPUT_DIR, "class_names.npy"), class_names)
np.save(os.path.join(OUTPUT_DIR, "all_labels.npy"),  all_labels)

with open(os.path.join(OUTPUT_DIR, "label_encoder.pkl"), "wb") as f:
    pickle.dump(le, f)

with open(os.path.join(OUTPUT_DIR, "manifest.json"), "w") as f:
    json.dump(manifest, f, indent=2)

config = {
    "dataset_dir":     DATASET_DIR,
    "random_state":    RANDOM_STATE,
    "min_samples":     MIN_SAMPLES,
    "merge_threshold": MERGE_THRESHOLD,
    "ngram_modes":     list(NGRAM_MODES.keys()),
    "vectorizers":     VECTORIZERS,
    "k_features":      [str(k) if k is not None else "all" for k in K_FEATURES],
    "n_classes":       int(len(class_names)),
    "n_samples":       int(len(y)),
    "n_variants":      total,
    "class_counts":    {cls: int(cnt) for cls, cnt in sorted(label_counts.items())},
}
with open(os.path.join(OUTPUT_DIR, "config.json"), "w") as f:
    json.dump(config, f, indent=2)

with open(os.path.join(OUTPUT_DIR, "samples.json"), "w") as f:
    json.dump(samples_list, f)

print(f"  Saved samples.json ({len(samples_list)} documents)")
print(f"  Saved y.npy, class_names.npy, all_labels.npy, label_encoder.pkl")
print(f"  Saved manifest.json  ({total} variants)")
print(f"  Saved config.json")

print(f"\n{'=' * 65}")
print(f"  Preprocessing complete.")
print(f"  {total} variants saved under '{OUTPUT_DIR}'")
print(f"  Run model.py next.")
print(f"{'=' * 65}")